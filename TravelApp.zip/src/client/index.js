import "./styles/style.scss";
import "./js/app";
