const { converDatetoGetTime } = require("../js/converDateToGetTime");

test("Test Data fetching method", () => {
  expect(converDatetoGetTime).toBeDefined();
});
